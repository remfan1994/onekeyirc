# onekeyirc 0.1.33

An application of ThatIAm.vip (www.thatiam.vip), designed by remfan1994.
Source is supplied under the included IALA (Insha-Allah License Agreement).
Read [LICENSE.md](LICENSE.md) and [NOTICE](NOTICE) before redistribution.

onekeyirc is the standalone, command-oriented IRC client. It keeps a live
conversation tail above a compact input field, can remain connected while
detached from SSH, and supports saved profiles for several IRC servers. It
uses POSIX terminal interfaces directly and has no curses or terminfo
dependency. The former standalone name was 1keyirc.

This recovery release fixes a minimalist terminal CPU spin after interrupted
review rendering, releases interrupted or rejected channel-directory requests,
and publishes installed executables atomically. It retains the preceding
security fixes and empty-by-default custom bindings. The dated reviews record
specific source versions, checks, and limits. Start with the current
[security guide](SECURITY.md) for operating assumptions and limits.

## Documentation map

- [INSTALL](INSTALL): dependencies, building, installation, checks, and upgrades.
- [MANUAL.txt](MANUAL.txt): the complete top-level program manual.
- [Getting started](doc/onekeyirc-start.txt): a short first-session walkthrough.
- [Configuration example](examples/onekeyirc.ini): supported INI sections and settings.
- [Key bindings](doc/HOTKEYS.txt): user-selected keys, actions, table and commands.
- [Bouncers](doc/BOUNCERS.txt): ZNC and soju profiles, playback, and privacy.
- [Session controls](doc/SESSION-CONTROLS.txt): attach, recover, detach, and close.
- [OpenBSD VPS guide](doc/OPENBSD-VPS.txt): saved startup and rc.d service setup.
- [SECURITY.md](SECURITY.md): trust boundaries, safe deployment, and reporting.
- [DESIGN.md](DESIGN.md): source structure and implementation invariants.
- [CHANGELOG.md](CHANGELOG.md): release history.

The instructions below describe the current source. Reports in `doc/` whose
names include a release or date remain historical records; read their scope
and environment notes before treating a reported check as applicable to a
different platform or build. In particular, see the
[current recovery review](doc/STABILITY-REVIEW-0.7.34-0.1.33.txt), the
[preceding security review](doc/SECURITY-REVIEW-0.7.33-0.1.32.txt), and
[OpenBSD validation record](doc/OPENBSD-VALIDATION.txt).

## Optional custom key bindings

No custom keys are assigned by default. Use `/bindings actions` and
`/bindings keys` to choose names, then assign only the keys you want:

    /bind F7 summary
    /bind Alt-c command
    /save input

These examples are not installed defaults. `/unbind F7` removes one binding;
`/unbind all` clears the list. Save with `/save input` to keep your choices
after restart. Bindings belong to the primary config and apply across servers.
The config format is an optional `[hotkeys]` section with `KEY=action` rows.

Full vipirc has an editable table at App -> Key bindings and `/bindings`.
The minimalist interface lists bindings and edits them with the commands
above. Only main chat and command entry accept custom actions; passwords,
paste, readers and confirmations keep their own controls. No arbitrary
commands or send macros are accepted. See [HOTKEYS.txt](doc/HOTKEYS.txt) for
the action list, draft protection, terminal aliases and saving behavior.

## Build and first connection

From the extracted source directory:

    ./configure
    make
    ./onekeyirc --help
    ./onekeyirc

Use `./onekeyirc` for the local build, or `onekeyirc` after installing it as
explained in INSTALL. The remaining examples use the installed command.
After dismissing the welcome, replace the example host, nick, and channel
with the ones supplied by your IRC operator:

    /connect -nick mynick irc.example.org 6697
    /join #mychannel

Wait for registration before joining. A new destination defaults to verified
TLS on port 6697. A port number alone does not disable TLS. `-tls` (also
`-ssl`) or a `+PORT` selects TLS explicitly; `-plain` explicitly selects
unencrypted IRC. Credential authentication requires verified TLS.

A matching saved server reuses its settings. `/server HOST [PORT]` is a
connection alias. With several identities on one bouncer host, select the
intended saved profile by number instead of assuming the hostname identifies
the right account. Without a supplied nickname, the client uses a valid Unix
login name, or `user` as a fallback.

`/quickstart` offers guided connection setup. `/panel` opens the settings
selector: 0 edits application preferences; 1 through 8 edit server profiles.
Read the final action before accepting it. Quickstart defaults to Connect
once, server panels to Save only, and application preferences to Save.
Saving or applying connection edits does not interrupt a live connection.

For an offline look at the interface:

    onekeyirc --test-mode

Test mode makes no IRC connections, does not read credential files or
decrypt secrets, and skips configuration and command-count saves. It is a
UI aid, not a test of your real server, password, certificate, or boot
setup.

## Save the connection and understand what is saved

After a successful connection:

    /autoconnect on
    /saveconf

`/autoconnect on` requests a connection at future startup. `/saveconf` saves
application preferences and healthy server profiles, and remembers the
selected server as the next-launch default when that profile saves
successfully. Saving alone never enables autoconnect. Leave autoconnect off
and use `/connect` after launch if you prefer manual connection.

Use the save scope that matches your change:

- `/save`: save the selected server's effective settings, including staged
  connection changes.
- `/save input` or `/save output`: save application preferences to the main
  config while preserving that file's first-server connection settings.
- `/save all`: save all healthy server profiles separately.
- `/saveconf`: save application preferences and profiles, and remember the
  selected server as described above.

Each file is replaced atomically, but a multi-profile save is not one
transaction. Check every diagnostic: an earlier successful save is not
rolled back if another profile fails.

`/autojoin add #mychannel` changes the next connection's channel list;
`/join #mychannel` joins now and updates the running list. Explicitly staged
`/autojoin` edits take precedence when saving. Keys supplied to `/join` are
not saved. Endpoint, TLS, authentication, and staged startup edits take
effect on the next explicit `/disconnect` then `/connect`. Automatic retries
retain the interrupted connection's settings.

## Configuration and local files

The default primary file is:

    $XDG_CONFIG_HOME/onekeyirc/config.ini
    $HOME/.config/onekeyirc/config.ini       when XDG_CONFIG_HOME is unset

`XDG_CONFIG_HOME`, when set, must be absolute. Use `--config FILE` (`-C FILE`)
for an exact alternate file. It must already exist unless you are creating
it with `--init-config`. For a new configuration only:

    onekeyirc --init-config
    onekeyirc --check-config

Initialization refuses to overwrite an existing file. `--check-config`
validates the main file and saved server profiles without connecting or
reading/decrypting credentials. It does not verify the remote account or
whether a GPG agent will be unlocked after reboot.

If the new default file is absent, an existing `1keyirc/config.ini` under
the same XDG/home base is reused in place, with its adjacent saved profiles.
The new path wins if both exist. Invalid or inaccessible candidates produce
an error; no configuration is silently moved. See
[rename and upgrade notes](doc/ONEKEYIRC-RENAME.txt).

The primary config owns application-wide input, output, session, and presence
preferences. Additional server profiles keep connection, authentication,
bouncer, startup, watch, and ignore settings beside it in the `.servers`
catalog and `.d` profile directory. Paths inside INI files are literal:
there is no shell quoting, `~` expansion, or `$HOME` expansion. Relative paths
are relative to the program's launch directory; absolute paths are best for
services and credentials.

Command-line `--nick`, `--port`, `--channel`, `--tls`, `--plain`, and `--ca-file`
overrides normally apply to the remembered default server. An explicit
`--server` selects the primary profile; changing its hostname clears the old
destination's credentials and startup state before connecting. This is not
a way to select an arbitrary saved bouncer identity. Configuration creation
and validation apply overrides to the primary file.

A `.commands` sidecar contains bounded command-name usage counts only, never
arguments or messages. Full command history, drafts, and ordinary scrollback
are in memory. Optional `.log` transcripts are described below. Copying the
main INI file alone is not a complete backup of a multi-server setup or its
separately stored credentials.

## Terminal interaction

Ordinary typing, Insert, or Enter from the live log opens Compose. A leading
`/` opens Command instead. The first typed character is retained. The default
`line` layout has one input row below the live tail. For a larger editor:

    /set composer_mode fullscreen
    /save input

Use `line` instead of `fullscreen` to return to the compact layout. Incoming
chat remains visible during composition and command entry.

Compose uses arrows to move the caret. Enter sends by default; Escape
cancels the draft and returns to the log. `/set send_mode review` adds a
review step; save it with `/save input`. A composition that needs several IRC
messages requires explicit split-send approval. The server's byte limit is
different from the number of rows drawn by your terminal.

In Command, Up recalls matching accepted commands; Down moves back toward
the current typed line or into suggestions. Enter on a selected suggestion
inserts it; a fresh Enter executes it. Tab completes commands or nicknames.
The command history is not a sent-chat history: Up in Compose moves the
caret and does not recall previously sent messages. Complete command history
lives in RAM, and sensitive commands are omitted.

From the watch log, Up/Down scroll rows, PageUp/PageDown scroll pages, Home
goes to the oldest retained text, and End returns to the live tail. Left,
Right, Delete, and Backspace do not open input from that view. Escape there
backgrounds the job; use `/quit` to end it deliberately.

Recognized bracketed paste is inserted literally and cannot execute a
command or send a message by itself. A pasted leading slash stays message
text; a fresh Enter is required. Unframed paste cannot reliably be
distinguished from typing. See the manual for terminal timing limits and
review controls.

The terminal's inherited signal-enabled state and interrupt, quit, and
suspend key assignments are preserved. The startup setting
`[input] force_terminal_signals=false` is the default; `true` enables terminal
signals without assigning Ctrl-C, Ctrl-Z, or any other key. Edit that setting
in the main config before launch. If your terminal already uses Ctrl-Z to
suspend, `fg` resumes it. Suspending is different from leaving the worker
running with `/background`. Without an explicit custom binding, literal Ctrl-D is not an application
exit shortcut. A terminal signal key mapped to that byte still follows the
inherited signal settings.

## Channels, queries, and server profiles

    /servers                 list server profiles; /sl is an alias
    /server 2                select profile 2 without connecting it
    /connect 2               connect profile 2
    /channels                list channel views; /cl is an alias
    /channel #mychannel      select an existing channel view
    /channel 0               show server messages and MOTD
    /queries                 list private conversations; /ql is an alias
    /query alice             open a query; /pm is an alias
    /part                    leave the current channel
    /close                   close the current retained conversation

Server numbers are 1 through 8; profile 1 is the permanent primary profile.
These are not the job numbers printed by `--sessions`. `/server add HOST
[PORT] [NICK]` creates an additional profile with fresh credentials and
manual connection, without selecting, connecting, or saving it. Removing a
secondary profile with `/server close NUMBER` removes its session/catalog
entry but leaves its configuration file on disk.

`/list` requests the network's channel directory, while `/channels` lists
the selected connection's retained channel views, including joined/parted
state. Use `/help list` for server masks and local filters. `/summary`
shows the current client state without making a remote request; it is
useful when diagnosing a connection.

## ZNC, soju, and credentials

Use a separate saved profile for each upstream bouncer network. In `/panel`,
set the TLS bouncer host/port, bouncer type, username, network, and optional
stable client identifier. The client constructs the required login identity.
Supply the bouncer password itself, not a hand-assembled password string.

- ZNC uses a server-password source. See [ZNC example](examples/bouncer-znc.ini).
- soju uses a SASL password source. See [soju example](examples/bouncer-soju.ini).

Credential sources can be an owned private password file, a GPG-encrypted
file, or an explicit private-config literal. Use exactly one source per
credential. Credential files must be owned regular files with mode 0600 or
0400; symlinks are rejected. Prefer the setup panel for entering credentials
without putting passwords into shell arguments or command history. Active
bouncer authentication changes belong in `/panel`, not `/autoauth` edits.

For a direct server profile, a private-file SASL setup can use:

    /autoauth sasl myaccount file /absolute/private/account.secret
    /save

Optional GPG credentials require GnuPG 2.2.20 or newer and an agent able to
decrypt without an interactive prompt. The panel can create a new encrypted
file for an existing local encryption key. It does not store the private
key's passphrase or unlock it at boot. See the manual before choosing GPG
for unattended startup.

Bouncers restore channel membership, so the client does not replay the saved
autojoin list for them. Explicit autocommands still run on registration.
Automatic idle/background AWAY is disabled for bouncer profiles unless
`automatic_away=true`; manual `/away` and `/back` remain available. Timestamped
history pushed by the bouncer is displayed with bounded retention. This is
not an on-demand archive browser or automatic multi-network discovery.

Use `/znc` or `/soju` for the corresponding service commands. ZNC module
messages such as `/msg *status ...` are also supported. These service commands
are excluded from input history and persistent transcripts; recognized
bouncer service replies go to the unlogged server view. TLS protects the
client-to-bouncer connection; upstream TLS and authentication are configured
on the bouncer separately.
Read [BOUNCERS.txt](doc/BOUNCERS.txt) for supported capabilities and limits.

## Keep a job running and recover after SSH drops

Inside the client, `/background` releases the terminal and keeps the managed
worker running. To start an unattended job from saved configuration:

    onekeyirc --background --reconnect
    onekeyirc --sessions
    onekeyirc --resume

A loaded configuration or explicit `--server` is required for unattended
startup. Save autoconnect first if you want saved profiles connected at
startup. A successful background launch means the local worker is ready;
inspect `/servers` or `/summary` after resuming to verify IRC registration.

The standalone client always uses its minimalist interface; `-N` is not
a supported frontend choice.

If a lost SSH terminal leaves a job marked attached or busy, first list the
jobs. Substitute the current job number, not a PID or server-profile number:

    onekeyirc --sessions
    onekeyirc --detach-session NUMBER
    onekeyirc --resume NUMBER

Detaching releases the terminal controller while preserving the worker,
connections, drafts, and retained history. To deliberately terminate that
entire job instead:

    onekeyirc --close-session NUMBER

Closing ends every IRC connection and transfer in the job; it cannot then
be resumed. `/quit` does the same from inside the client. If close times out,
an accepted request may still finish later; recheck `--sessions` before
assuming it is still live. Do not delete session files or signal an assumed
PID based on the job number.

Session management options are separate operations. Do not mix them with
`--config`, connection options, or `--background`. Run them as the same Unix
account and client namespace that started the worker. `/set single_session
on` followed by `/save input` can limit that namespace to one background job;
it does not limit the IRC connections inside that job.

`--reconnect` retries transient failures with delays increasing from 5 to
300 seconds. It does not itself initiate a connection or save a preference.
Certificate, authentication, configuration, and protocol failures are held
for correction. `/disconnect` cancels retry until an explicit connection.
`--no-connect` suppresses startup connections. Unsent chat is discarded after
a lost connection, and saved autocommands run on each new registration.

Use the managed background workflow before relying on survival of terminal
loss. A VPS reboot or worker exit ends that process's in-memory history and
drafts. A boot service starts a new worker from saved configuration. See
[SESSION-CONTROLS.txt](doc/SESSION-CONTROLS.txt) and the
[OpenBSD guide](doc/OPENBSD-VPS.txt).

## Logs, catch-up, and limits

Persistent logging is off by default. To enable it and remember the choice:

    /set persistent_logging on
    /save output

Each saved profile appends to its adjacent `.log`; unsaved profiles retain
only RAM history. The log must be an owned regular 0600 file in an owned
0700 directory. Each file stops at 16 MiB rather than growing indefinitely;
live chat continues. Turn logging off, archive the log, then enable it again.
Do not loosen the file checks to work around a refusal.

In the minimalist interface, `/catchup` returns to the last locally sent
composition's anchor in the selected channel or query. It tries an eligible
private log first, then retained RAM. Logging must already have been
enabled when the anchor was created and remain healthy. It does not import
old logs at startup or recover anchors from an exited process. Rotation or
replacement invalidates a disk anchor; available RAM may still be used.
Ordinary scrolling also has bounded retention.

DCC SEND is optional active IPv4 file transfer. Every incoming offer needs
explicit acceptance. DCC is a separate direct, unencrypted, unauthenticated
peer connection even when IRC uses TLS. Paths are literal, existing files
are not overwritten, and incoming files require a private receive directory.
Read the manual and SECURITY.md before accepting or offering a file.

## Troubleshooting

- A second display row appears clipped: switch back to that conversation or
  return to its live tail and compare retained text. Drawing, local echo,
  server receipt, and another user's receipt are separate things. Do not
  resend solely because a row is missing. Report the exact version, terminal,
  dimensions, interface, paste method, and steps with nonprivate sample text.
- Up does not reload a sent message: command history belongs to Command;
  Compose arrows move the caret. Chat drafts are not a sent-message recall
  list. See the input section above.
- Resume says busy: use the inspect/detach/resume sequence above. Close only
  when the entire job should end.
- A setting did not survive restart: verify the save scope and diagnostic,
  and whether you launched with the same config path and Unix account.
- TLS or authentication is held: inspect server view 0 and `/summary`, check
  hostname, certificate trust, credential ownership/mode, and GPG readiness,
  then explicitly reconnect after correcting the cause.
- Logging stops: check the diagnostic, private directory/file ownership,
  concurrent use, and the 16 MiB limit. Live chat may still be working.
- A new executable seems unchanged: installed files do not replace code in
  an already running worker. Close that job deliberately and launch the new
  version; old RAM history and drafts end with the old process.

For reports, include `onekeyirc --version`, the OS and terminal, interface,
exact nonsecret steps, and whether the issue occurs in `--test-mode`.
Redact credentials, channel keys, private messages, and identifying paths.
Security-sensitive findings should follow SECURITY.md rather than a public
transcript dump.

## Help, local notice, and attribution

    onekeyirc --help
    onekeyirc --manual
    man onekeyirc

Inside the client, `/help` opens the reader and `/help COMMAND` explains a
command. `/manual` opens the full manual. Help can be read offline.

Once per running worker, the ordinary display includes this local notice:

    Cow killing is the bloodshed of the innocent. www.bloodguiltcurse.net - ban beef.

It is not sent to IRC or inserted into AWAY text. An unattended worker shows
it when a display becomes available; reconnecting, changing channels, and
reattaching do not create new notices for that same worker.

ThatIAm.vip and remfan1994 attribution and the supplied IALA license remain
in NOTICE and LICENSE.md. Dependency licenses and maintenance remain those
of the installed dependency versions.
